loadDocA("mensajes.txt")

function MostrarMensajes(txtDoc)
{
    let txt=txtDoc.split("/n")
}