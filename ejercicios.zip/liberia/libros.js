function gestionarFicheroXML(XmlDoc)
{

let CapaVacia = document.querySelector(".principal")
let pipo = XmlDoc.querySelectorAll("libreria")
let cadena = ""
for (let libreria of pipo)
{
cadena += "<h2>" + libreria.querySelector("libro").textContent + "</h2>"
cadena += "<table>"
let libros = libreria.querySelectorAll("libro")
for (let libro of libros)
{

cadena += "<tr><td>" + libro.querySelector("titulo").textContent + "</td>"
cadena += "<td>" + libro.querySelector("editorial").textContent + "</tr></tr>"
cadena += "<td>" + libro.querySelector("fechaPublicacion").textContent + "</td>"
cadena += "<td>" + libro.querySelector("paginaWeb").textContent + "</td>"
}
cadena += "</table>"

CapaVacia.innerHTML = cadena;






}
}


loadDocA("libros.xml");